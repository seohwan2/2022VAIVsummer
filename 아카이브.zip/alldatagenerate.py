import subprocess
import os
import sys

# 추후에 trading period도 조정 가능하도록 수정하기 (argument로 입력하도록 설정)
KospiorKosdaq = sys.argv[1]
Stockdataskos = 'stockdatas'+KospiorKosdaq
for filename in os.listdir(Stockdataskos):
    # python run_binary_preprocessing.py 2880.TW 20 50
    # filename : 2880.TW_training.csv
    ticker = filename.split('_')[0]   # 2880.TW

    # exception : ^BSESN_testing.csv
    # 예외처리 어떻게 할 지 몰라서 그냥 수작업으로 함
    if ticker == '^BSESN' or ticker == '^JKSE' or ticker == '^NSEI':
        continue
    if ticker == 'AAPL' or ticker == 'EWT' or ticker == 'FTW' or ticker == 'GE':
        continue

    is_invalid = True

    training = filename.split('_')[1]   # training.csv
    #print("country :", country)

    # country = ticker.split('.')[1]    # TW
    if training == 'training.csv':
        is_invalid = False
    # if country == 'TW' or country == 'tw':
    #     is_invalid = False
    # if country == 'JK' or country == 'jk':
    #     is_invalid = False
    # if is_invalid:
    #     continue
    #print("filename :", filename)
    print(KospiorKosdaq)
    subprocess.call(f'python run_binary_preprocessing.py {ticker} 20 50 {KospiorKosdaq}', shell=True)
    print("\n*** Running binary preprocessing is completed. ***\n")
    ticker_code = ticker.replace('.', '')  
    subprocess.call(f'python generatedata.py dataset_{KospiorKosdaq} 20_50/{ticker} dataset_{ticker_code}_20_50', shell=True)
    print("\n*** Running dataset generating is completed. ***\n")
    #print("ticker (expected : 0000.TW) ->", ticker)
    #print(f'python run_binary_preprocessing.py {ticker} 20 50')
    #subprocess.call('python run_binary_preprocessing.py 2880.TW 20 50')
    #print(f'python run_binary_preprocessing.py {ticker} 20 50')
    #print(f'* loading {filename} data')

# for filename in os.listdir('stockdatas'):
#     # python generatedata.py dataset 20_50/2880.TW dataset_2880TW_20_50
#     ticker = filename.split('_')[0]   # 2880.TW

#     # exception : ^BSESN_testing.csv
#     # 예외처리 어떻게 할 지 몰라서 그냥 수작업으로 함
#     if ticker == '^BSESN' or ticker == '^JKSE' or ticker == '^NSEI':
#         continue
#     if ticker == 'AAPL' or ticker == 'EWT' or ticker == 'FTW' or ticker == 'GE':
#         continue

#     country = filename.split('.')[1]    # TW
#     training = filename.split('_')[1]   # training.csv
#     #print("country :", country)
#     is_invalid = True

#     if training == 'training.csv':
#         is_invalid = False
#     if country == 'TW' or country == 'tw':
#         is_invalid = False
#     if country == 'JK' or country == 'jk':
#         is_invalid = False
#     if is_invalid:
#         continue
#     ticker_code = ticker.replace('.', '')     # 2880TW
#     subprocess.call(f'python generatedata.py dataset 20_50/{ticker} dataset_{ticker_code}_20_50', shell=True)
#     #print(f'python generatedata.py dataset 20_50/{ticker} dataset_{ticker_code}_20_50')
#     #print(f'* loading {filename} data')

    

# - 오류 수정
# - 실행 전에 두 개 for문 맨 밑에 break 지우고 실행하기
# - stockdatas에서 0050.TW의 경우 testing.csv 밖에 없어서 코드 오류남 -> stockdatas에서 0050.TW_testing.csv 지우고 실행하기