from posixpath import split
import FinanceDataReader as fdr
import time
import csv

df = fdr.StockListing("KOSPI")
# df = df.loc[df['Name'].str[-1] == "콜" & df['Sector'].isnull()]
# df = df.loc[df['Name'].str[-1] == "풋" & df['Sector'].isnull()]
a = 0

for code, name, date in df[['Symbol', 'Name', 'ListingDate']].values:
    print(code, name)
    while True:
        try:
            str_date = str(date)
            split_date = str_date.split('-')[0]
            if(int(split_date) <= 1999):
                break
            elif(int(split_date) >= 2017):
                break
            if(len(str(date)) == 3):
                break
            data = fdr.DataReader(code, start = '20000101', end = '20161231')
            data.to_csv("/home/ubuntu/2022_VAIV_SeoHwan/stockdataskospi/{}_training.csv".format(code))
            a+=1
            print("Create csv!")
            time.sleep(1)
            break
        except ValueError:
            break
    if(a == 50):
        break
            